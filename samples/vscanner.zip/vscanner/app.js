const express = require('express');
const bodyParser = require('body-parser');
const routes = require("./routes/index");
const cors = require('cors');
const morgan = require('morgan');

// Initialize express app
const app = express();
const port = process.env.VSCANNER_PORT || 3018;

// Apply middlewares
app.use(morgan('dev')); // Logging middleware
app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json({ limit: '10mb' })); // Parse JSON bodies
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' })); // Parse URL-encoded bodies

app.use("/scanner", routes);

// 404 handler - for routes that don't exist
app.use((req, res, next) => {
  const error = new Error(`Route ${req.originalUrl} not found`);
  error.status = 404;
  next(error);
});

// Global error handler
app.use((err, req, res, next) => {
  const statusCode = err.status || 500;
  console.error(err.message, err.stack);
  
  res.status(statusCode).json({
    status: 'error',
    statusCode,
    message: err.message,
    data: err.data,
    stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
