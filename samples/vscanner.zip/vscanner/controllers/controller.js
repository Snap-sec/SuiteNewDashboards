const catchError = require("../utils/catchError");
const { generateCommands } = require("../utils/generateCommands");
const { runNuclei } = require("../executor/executor");
const { parseResult } = require("../services/parser.service");
const { sendResults } = require("../utils/sendResult"); 


const startScan = catchError(async (req, res) => {
    const { scanId } = req.params;
    const { scanType, webhookUrl, assets, orgId, scannerId } = req.body;

    console.log(scanId, scanType, webhookUrl, assets);

    // nuclei options
    const options = generateCommands(scanType, assets);
    console.log("command options: ", options);

    // Process in batches of 5
    const batchSize = 5;
    for (let i = 0; i < options.length; i += batchSize) {
        const batch = options.slice(i, i + batchSize);
        
        // Wait for the current batch to complete before moving to the next
        await Promise.all(batch.map(option => 
            runNuclei(option, scanId)
                .then((data) => {
                    let parsedResult = parseResult(option.asset, scanType, scanId, scannerId, orgId, data);
                    console.log('FINAL RESULT: ', parsedResult[0]);
                    
                    return sendResults(webhookUrl, parsedResult)
                        .then(() => console.log("result has been sent"))
                        .catch((err) => console.log("error while sending result to the webhook."));
                })
                .catch((err) => console.log('[-] Error while executing nuclei : ', err))
        ));
        
        console.log(`Completed batch ${Math.floor(i/batchSize) + 1} of ${Math.ceil(options.length/batchSize)}`);
    }

    return res.json({ message: "Scan started." });
});


module.exports = { startScan };