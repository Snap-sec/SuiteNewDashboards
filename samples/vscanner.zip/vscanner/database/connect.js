const sqlite = require("sqlite3");
const { open } = require("sqlite");

var db = null;

async function connectDb(){
    if (db) return db;

    db = await open({
        filename: 'database.db',
        driver: sqlite.cached.Database
    });

    console.log('[+] CONNECTED SQLITE');

    // create table
    await db.exec(`CREATE TABLE IF NOT EXISTS scans (
        scanId TEXT,
        pid TEXT
    )`);

    // create required scan stats table
    await db.exec(`CREATE TABLE IF NOT EXISTS scan_stats (
        scanId TEXT UNIQUE,
        percent TEXT,
        duration TEXT,
        requests TEXT,
        rps TEXT
    )`);

    return db;
}


async function getPids(scanId) {
    try {
        const db = await connectDb();
        const pids = await db.all(`SELECT pid FROM scans WHERE scanId = '${scanId}'`);
        return pids;
    } catch (error) {
        console.error('[-] ERROR GETTING PIDS: ', error);
    }
}

async function addScan(scanId, pid){
    try {
        const db = await connectDb();
        await db.exec(`INSERT INTO scans (scanId, pid) VALUES ('${scanId}', '${pid}')`);
    } catch (error) {
        console.error('[-] ERROR ADDING SCAN: ', error);
    }
}

async function removeScan(scanId){
    try {
        const db = await connectDb();
        await db.exec(`DELETE FROM scans WHERE scanId = '${scanId}'`);
    } catch (error) {
        console.error('[-] ERROR REMOVING SCAN: ', error);
    }
}

async function addScanStats(scanId, stats){
    try {
        const db = await connectDb();
        await db.exec(`INSERT OR REPLACE INTO scan_stats (scanId, percent, duration, requests, rps) VALUES ('${scanId}', '${stats.percent}', '${stats.duration}', '${stats.requests}', '${stats.rps}')`);
    } catch (error) {
        console.error('[-] ERROR ADDING SCAN STATS: ', error);
    }
}

async function getScanStats(scanId){
    try {
        const db = await connectDb();
        const stats = await db.get(`SELECT percent, duration, requests, rps, scanId FROM scan_stats WHERE scanId = '${scanId}'`);
        return stats;
    } catch (error) {
        console.error('[-] ERROR GETTING SCAN STATS: ', error);
    }
}



module.exports = { connectDb, addScan, removeScan, getPids, addScanStats, getScanStats }