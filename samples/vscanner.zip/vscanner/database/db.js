const { connectDb } = require("./connect");

class SQLite {
    static _instance = null;

    constructor() {
        this.db = null;
    }

    async connect() {
        this.db = await connectDb();

        // init the database
        await this.init();
    }

    async init() {
        if (!this.db) {
            throw new Error("Database not connected");
        }

        // create required scans table
        await this.db.exec(`CREATE TABLE IF NOT EXISTS scans (
            scanId TEXT,
            pid TEXT
        )`);

        // create required scan stats table
        await this.db.exec(`CREATE TABLE IF NOT EXISTS scan_stats (
            scanId TEXT UNIQUE,
            percent TEXT,
            duration TEXT,
            requests TEXT,
            rps TEXT
        )`);
    }
   
    static async getInstance() {
        if (!SQLite._instance) {
            SQLite._instance = new SQLite();
            await SQLite._instance.connect();
        }
        return SQLite._instance;
    }

    async getPids(scanId) {
        const pids = await this.db.all(`SELECT pid FROM scans WHERE scanId = ?`, [scanId]);
        return pids;
    }

    async addScan(scanId, pid) {
        return await this.db.run(`INSERT INTO scans (scanId, pid) VALUES (?, ?)`, [scanId, pid]);
    }

    async removeScan(scanId) {
        return await this.db.run(`DELETE FROM scans WHERE scanId = ?`, [scanId]);
    }

    async addScanStats(scanId, stats) {
        return await this.db.run(
            `INSERT OR REPLACE INTO scan_stats (scanId, percent, duration, requests, rps) VALUES (?, ?, ?, ?, ?)`,
            [scanId, stats.percent, stats.duration, stats.requests, stats.rps]
        );
    }

    async getScanStats(scanId) {
        const stats = await this.db.get(`SELECT percent, duration, requests, rps, scanId FROM scan_stats WHERE scanId = ?`, [scanId]);
        return stats;
    }
}


module.exports = { db: SQLite.getInstance() };