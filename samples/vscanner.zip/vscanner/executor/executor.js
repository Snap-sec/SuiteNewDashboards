const { spawn } = require('child_process');
const { addScan, addScanStats, removeScan } = require("../database/connect");

// Function to execute Nuclei and return JSON data
function runNuclei(options, scanId='') {
  return new Promise((resolve, reject) => {
    // Array to store JSON results
    let jsonResults = [];

    console.log("command: ", `nuclei ${options.options.join(' ')}`)

    // Spawn the Nuclei process
    const nuclei = spawn('nuclei', options.options, { cwd: process.cwd()});

    const pid = nuclei.pid;

    addScan(scanId, pid);

    // Buffer to accumulate data chunks
    let outputBuffer = '';

    // Capture stdout (standard output)
    nuclei.stdout.on('data', (data) => {
      outputBuffer += data.toString();
      // Split by newlines and process each line
      const lines = outputBuffer.split('\n');

      // Keep the last incomplete line in the buffer
      outputBuffer = lines.pop();

      // Parse each complete line as JSON
      lines.forEach((line) => {
        if (line.trim()) { // Ignore empty lines
          try {
            const jsonData = JSON.parse(line);

            jsonResults.push(jsonData);

          } catch (err) {
            console.error('Error parsing JSON:', err.message);
          }
        }
      });
    });

    // Capture stderr (errors)
    nuclei.stderr.on('data', (data) => {
      console.log("[-] ERROR: ", data.toString());
      try {
        const jsonData = JSON.parse(data.toString());

        if (jsonData.percent) {
          console.log("[+] COMPLETED " + jsonData.percent + "%");
          addScanStats(scanId, jsonData);
        }
      } catch (err) {
        console.error('Error parsing JSON:', err.message);
      }
    });

    // Handle process completion
    nuclei.on('close', (code) => {
      removeScan(scanId);
      if (code === 0) {
        // Process any remaining data in the buffer
        if (outputBuffer.trim()) {
          try {
            const jsonData = JSON.parse(outputBuffer);
            jsonResults.push(jsonData);
          } catch (err) {
            console.error('Error parsing final JSON:', err.message);
          }
        }
        resolve(jsonResults);
      } else {
        reject(new Error(`Nuclei process exited with code ${code}`));
      }
    });

    // Handle spawn errors (e.g., Nuclei not found)
    nuclei.on('error', (err) => {
      removeScan(scanId);
      reject(new Error(`Failed to spawn Nuclei: ${err.message}`));
    });
  });
}

module.exports = { runNuclei }