const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const { getPids, removeScan, getScanStats, removeScanStats } = require("../database/connect");

const controller = require("../controllers/controller");


router.post("/start/:scanId", controller.startScan);

router.post("/stop/:scanId", async (req, res) => {
    const { scanId } = req.params;

    const pids = await getPids(scanId);

    const pidsList = pids.map(pid => pid.pid);

    console.log("pids: ", pidsList);

    pidsList.forEach(pid => {
        exec(`kill -9 ${pid}`, (error, stdout, stderr) => {
            if (error) {
                console.log("[-] Error while killing the process: ", error);
            }
            else if (stderr) {
                console.log("[-] Error while killing the process: ", stderr);
            }
            else {
                console.log("[+] Process killed successfully", stdout);
            }
        });
    })

    if (!pids || pids.length === 0) {
        return res.status(404).json({ message: "Scan not found" });
    }

    await removeScan(scanId);

    return res.status(200).json({ message: "Scan halted" });
});


router.get("/heartbeat", async (req, res) => {
    return res.json({ message: "I am alive" });
});


router.get("/stats/:scanId", async (req, res) => {
    const { scanId } = req.params;

    const stats = await getScanStats(scanId);

    console.log("stats: ", stats);

    return res.json(stats);
});


module.exports = router;