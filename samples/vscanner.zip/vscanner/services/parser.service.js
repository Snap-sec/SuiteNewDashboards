
const parseResult = (asset, scanType, scanId, scannerId, orgId, records) => {
    console.log("[+] TOTAL RESULTS", records.length)

    let parsedRecords = [];

    for (let record of records) {
        let parsed = {
            orgId: orgId,
            type: asset.type,
            value: asset.value,
            scanType: scanType,
            scanId: scanId,
            title: record.info.name,
            description: record.info.description,
            host: record.host,
            port: record.port,
            url: record.url,
            ip: record.ip,
            scannerId: scannerId,
            tags: record.info.tags,
            severity: record.info.severity,
            metadata: record.info.metadata,
            curl: record["curl-command"],
            matched_at: record['matched-at'],
            matcher_name: record['matcher-name'],
            _raw: record
        };

        parsedRecords.push(parsed);
    }

    return parsedRecords;
}

module.exports = { parseResult };