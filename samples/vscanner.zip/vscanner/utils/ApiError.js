// ApiError.js
class ApiError extends Error {
  constructor(message, statusCode, data = null) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.status = statusCode;
    this.data = data;

    // Capture stack trace, excluding the constructor call from the stack
    Error.captureStackTrace(this, this.constructor);
  }

  static badRequest(message, data) {
    return new ApiError(message || 'Bad Request', 400, data);
  }

  static unauthorized(message, data) {
    return new ApiError(message || 'Unauthorized', 401, data);
  }

  static forbidden(message, data) {
    return new ApiError(message || 'Forbidden', 403, data);
  }

  static notFound(message, data) {
    return new ApiError(message || 'Resource Not Found', 404, data);
  }

  static methodNotAllowed(message, data) {
    return new ApiError(message || 'Method Not Allowed', 405, data);
  }

  static conflict(message, data) {
    return new ApiError(message || 'Conflict', 409, data);
  }

  static validationError(message, data) {
    return new ApiError(message || 'Validation Error', 422, data);
  }

  static internal(message, data) {
    return new ApiError(message || 'Internal Server Error', 500, data);
  }
}

module.exports = ApiError;