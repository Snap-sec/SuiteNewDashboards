// catchError.js
/**
 * Wraps an async controller function to catch errors and forward them to the Express error handler
 * @param {Function} controller - The async controller function to wrap
 * @returns {Function} - Express middleware function that catches errors
 */
const catchError = (controller) => {
  return async (req, res, next) => {
    try {
      await controller(req, res, next);
    } catch (error) {
      // Forward the error to the global error handler
      next(error);
    }
  };
};

module.exports = catchError;