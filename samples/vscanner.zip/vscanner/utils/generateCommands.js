
const generateCommands = (scanType, assets) => {
    let options = [];

    for (let asset of assets) {
        if (scanType == "test") {
            options.push({ options: ['-u', asset.value, '-t', '/app/nuclei-templates/http/misconfiguration/http-missing-security-headers.yaml', '-j', '-stats', '--silent'], asset: asset });
        }
        else if (scanType == "full") {
            options.push({ options: ['-u', asset.value, '-j', '-stats', '--silent'], asset: asset });
        }
    }

    return options;
}

module.exports = { generateCommands };