const axios = require("axios");


const sendResults = async (webhookUrl, results) => {
    const response = await axios.post(webhookUrl, results, {
        headers: {
            'Content-Type': "application/json"
        },
        validateStatus: () => true
    });

    console.log("[+] Results have been sent ", results.length);

    return response.data;
}


module.exports = { sendResults }